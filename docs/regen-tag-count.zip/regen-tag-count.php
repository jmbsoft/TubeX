<?php

define('TUBEX_CONTROL_PANEL', true);
require_once '../admin/includes/cp-global.php';

$DB = GetDB();
$DB->Update('DELETE FROM `tbx_video_tag`');

$result = $DB->Query('SELECT `tags` FROM `tbx_video`');

while( $video = $DB->NextRow($result) )
{
    Tags::AddToFrequency($video['tags']);
}

$DB->Free($result);

echo "COMPLETE!";

?>