<?php

require_once 'includes/cp-global.php';

$DB = GetDB();

$pid = Cache_MySQL::Get('thumb-queue-pid');

if( empty($pid) )
{
    echo "The thumb queue is not running!";
}
else
{
    shell_exec('kill -9 ' . $pid);
    echo "The thumb queue process has been killed";
}

?>